<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    
    // Email configuration
    $to = 'grjattain21@gmail.com'; // Your email address
    $subject = 'New Contact Form Submission';
    
    // Email body
    $email_body = "You have received a new message from your website contact form.\n\n" .
                  "Name: $name\n" .
                  "Email: $email\n" .
                  "Message:\n$message";
    
    // Create PHPMailer object
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.mailtrap.io';  // Update with your SMTP host
        $mail->SMTPAuth = true;
        $mail->Username = '40879baa893828';  // Your Mailtrap username
        $mail->Password = '9b622baf4c388a';  // Your Mailtrap password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Remove or comment out the debug output
        // $mail->SMTPDebug = 2;
        // $mail->Debugoutput = 'html';

        $mail->setFrom('your-email@example.com', 'Enquiry');  // Update with your email
        $mail->addAddress($to);
        $mail->Subject = $subject;
        $mail->Body = $email_body;

        $mail->send();
        // Display success message and redirect
        echo "<script>alert('Your message has been sent. Thank you!'); window.location.href = '/';</script>";
    } catch (Exception $e) {
        // Display error message and redirect
        echo "<script>alert('Sorry, there was an error sending your message. Please try again later.'); window.location.href = 'your-redirect-page.php';</script>";
    }
}
?>

